import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  primaryKey,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  title: varchar("title"),
  bio: text("bio"),
  skillCoinBalance: integer("skill_coin_balance").default(100),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("5.0"),
  totalReviews: integer("total_reviews").default(0),
  skillsShared: integer("skills_shared").default(0),
  skillsLearned: integer("skills_learned").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  category: varchar("category").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userSkills = pgTable("user_skills", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  skillId: integer("skill_id").references(() => skills.id).notNull(),
  proficiencyLevel: varchar("proficiency_level").notNull(), // beginner, intermediate, advanced, expert
  isOffering: boolean("is_offering").default(true),
  isSeeking: boolean("is_seeking").default(false),
  hourlyRate: integer("hourly_rate"), // in SkillCoins
  createdAt: timestamp("created_at").defaultNow(),
});

export const skillExchanges = pgTable("skill_exchanges", {
  id: serial("id").primaryKey(),
  mentorId: varchar("mentor_id").references(() => users.id).notNull(),
  menteeId: varchar("mentee_id").references(() => users.id).notNull(),
  skillOfferedId: integer("skill_offered_id").references(() => skills.id).notNull(),
  skillSoughtId: integer("skill_sought_id").references(() => skills.id).notNull(),
  status: varchar("status").default("pending"), // pending, accepted, in_progress, completed, cancelled
  hoursPerWeek: integer("hours_per_week").default(2),
  schedule: text("schedule"),
  message: text("message"),
  matchScore: integer("match_score"), // AI matching score 0-100
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const skillCoinTransactions = pgTable("skill_coin_transactions", {
  id: serial("id").primaryKey(),
  fromUserId: varchar("from_user_id").references(() => users.id),
  toUserId: varchar("to_user_id").references(() => users.id).notNull(),
  amount: integer("amount").notNull(),
  type: varchar("type").notNull(), // earning, spending, transfer
  description: text("description"),
  exchangeId: integer("exchange_id").references(() => skillExchanges.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const nftBadges = pgTable("nft_badges", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: varchar("name").notNull(),
  description: text("description"),
  imageUrl: varchar("image_url"),
  skillId: integer("skill_id").references(() => skills.id),
  metadata: jsonb("metadata"),
  mintedAt: timestamp("minted_at").defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  reviewerId: varchar("reviewer_id").references(() => users.id).notNull(),
  revieweeId: varchar("reviewee_id").references(() => users.id).notNull(),
  exchangeId: integer("exchange_id").references(() => skillExchanges.id).notNull(),
  rating: integer("rating").notNull(), // 1-5 stars
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: varchar("type").notNull(), // match_found, exchange_request, exchange_accepted, etc.
  title: varchar("title").notNull(),
  message: text("message"),
  isRead: boolean("is_read").default(false),
  relatedId: integer("related_id"), // ID of related exchange, user, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Skill = typeof skills.$inferSelect;
export type InsertSkill = typeof skills.$inferInsert;
export type UserSkill = typeof userSkills.$inferSelect;
export type InsertUserSkill = typeof userSkills.$inferInsert;
export type SkillExchange = typeof skillExchanges.$inferSelect;
export type InsertSkillExchange = typeof skillExchanges.$inferInsert;
export type SkillCoinTransaction = typeof skillCoinTransactions.$inferSelect;
export type InsertSkillCoinTransaction = typeof skillCoinTransactions.$inferInsert;
export type NFTBadge = typeof nftBadges.$inferSelect;
export type InsertNFTBadge = typeof nftBadges.$inferInsert;
export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// Database relations
import { relations } from "drizzle-orm";

export const usersRelations = relations(users, ({ many }) => ({
  userSkills: many(userSkills),
  mentorExchanges: many(skillExchanges, { relationName: "mentor" }),
  menteeExchanges: many(skillExchanges, { relationName: "mentee" }),
  transactionsReceived: many(skillCoinTransactions, { relationName: "receiver" }),
  transactionsSent: many(skillCoinTransactions, { relationName: "sender" }),
  badges: many(nftBadges),
  reviewsGiven: many(reviews, { relationName: "reviewer" }),
  reviewsReceived: many(reviews, { relationName: "reviewee" }),
  notifications: many(notifications),
}));

export const skillsRelations = relations(skills, ({ many }) => ({
  userSkills: many(userSkills),
  exchangesOffered: many(skillExchanges, { relationName: "skillOffered" }),
  exchangesSought: many(skillExchanges, { relationName: "skillSought" }),
  badges: many(nftBadges),
}));

export const userSkillsRelations = relations(userSkills, ({ one }) => ({
  user: one(users, { fields: [userSkills.userId], references: [users.id] }),
  skill: one(skills, { fields: [userSkills.skillId], references: [skills.id] }),
}));

export const skillExchangesRelations = relations(skillExchanges, ({ one }) => ({
  mentor: one(users, { fields: [skillExchanges.mentorId], references: [users.id], relationName: "mentor" }),
  mentee: one(users, { fields: [skillExchanges.menteeId], references: [users.id], relationName: "mentee" }),
  skillOffered: one(skills, { fields: [skillExchanges.skillOfferedId], references: [skills.id], relationName: "skillOffered" }),
  skillSought: one(skills, { fields: [skillExchanges.skillSoughtId], references: [skills.id], relationName: "skillSought" }),
}));

export const skillCoinTransactionsRelations = relations(skillCoinTransactions, ({ one }) => ({
  fromUser: one(users, { fields: [skillCoinTransactions.fromUserId], references: [users.id], relationName: "sender" }),
  toUser: one(users, { fields: [skillCoinTransactions.toUserId], references: [users.id], relationName: "receiver" }),
  exchange: one(skillExchanges, { fields: [skillCoinTransactions.exchangeId], references: [skillExchanges.id] }),
}));

export const nftBadgesRelations = relations(nftBadges, ({ one }) => ({
  user: one(users, { fields: [nftBadges.userId], references: [users.id] }),
  skill: one(skills, { fields: [nftBadges.skillId], references: [skills.id] }),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  reviewer: one(users, { fields: [reviews.reviewerId], references: [users.id], relationName: "reviewer" }),
  reviewee: one(users, { fields: [reviews.revieweeId], references: [users.id], relationName: "reviewee" }),
  exchange: one(skillExchanges, { fields: [reviews.exchangeId], references: [skillExchanges.id] }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] }),
}));

// Insert schemas
export const insertSkillSchema = createInsertSchema(skills).omit({ id: true, createdAt: true });
export const insertUserSkillSchema = createInsertSchema(userSkills).omit({ id: true, createdAt: true });
export const insertSkillExchangeSchema = createInsertSchema(skillExchanges).omit({ id: true, createdAt: true, updatedAt: true });
export const insertReviewSchema = createInsertSchema(reviews).omit({ id: true, createdAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });
