import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import SkillCard from "@/components/skill-exchange/skill-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Search, 
  Filter, 
  TrendingUp, 
  Users, 
  BookOpen,
  Star
} from "lucide-react";
import type { Skill, SkillExchange } from "@/types";

export default function Skills() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [viewMode, setViewMode] = useState<"browse" | "exchanges">("browse");

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: skills, isLoading: skillsLoading } = useQuery<Skill[]>({
    queryKey: ["/api/skills"],
    enabled: !!user,
    retry: false,
  });

  const { data: skillExchanges, isLoading: exchangesLoading } = useQuery<SkillExchange[]>({
    queryKey: ["/api/skill-exchanges"],
    enabled: !!user && viewMode === "exchanges",
    retry: false,
  });

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-neutral-50 dark:bg-neutral-900">
        <Navbar />
        <div className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  // Get unique categories from skills
  const categories = skills ? [...new Set(skills.map(skill => skill.category))] : [];

  // Filter skills based on search and category
  const filteredSkills = skills?.filter(skill => {
    const matchesSearch = skill.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         skill.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || skill.category === selectedCategory;
    return matchesSearch && matchesCategory;
  }) || [];

  // Filter exchanges based on search
  const filteredExchanges = skillExchanges?.filter(exchange => {
    const searchLower = searchQuery.toLowerCase();
    return exchange.skillOffered.name.toLowerCase().includes(searchLower) ||
           exchange.skillSought.name.toLowerCase().includes(searchLower) ||
           exchange.mentor.firstName?.toLowerCase().includes(searchLower) ||
           exchange.mentor.lastName?.toLowerCase().includes(searchLower);
  }) || [];

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-900">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-neutral-900 dark:text-white mb-2">
              Skill Marketplace
            </h1>
            <p className="text-neutral-600 dark:text-neutral-300">
              Discover skills to learn and opportunities to teach
            </p>
          </div>
          
          <div className="flex items-center space-x-4 mt-4 lg:mt-0">
            <div className="flex border border-neutral-200 dark:border-neutral-700 rounded-lg">
              <Button
                variant={viewMode === "browse" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("browse")}
                className="rounded-r-none"
              >
                <BookOpen className="h-4 w-4 mr-2" />
                Browse Skills
              </Button>
              <Button
                variant={viewMode === "exchanges" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("exchanges")}
                className="rounded-l-none"
              >
                <Users className="h-4 w-4 mr-2" />
                Active Exchanges
              </Button>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-4 w-4" />
                <Input
                  placeholder={`Search ${viewMode === "browse" ? "skills" : "exchanges"}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              {viewMode === "browse" && (
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full lg:w-48">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              
              <Button variant="outline" size="default">
                <Filter className="h-4 w-4 mr-2" />
                More Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Content based on view mode */}
        {viewMode === "browse" ? (
          <div>
            {/* Skills Grid */}
            {skillsLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredSkills.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredSkills.map((skill) => (
                  <Card key={skill.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">{skill.name}</CardTitle>
                          <Badge variant="outline" className="mt-2">
                            {skill.category}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center text-yellow-400 mb-1">
                            <Star className="h-4 w-4 fill-current" />
                            <span className="ml-1 text-sm text-neutral-600 dark:text-neutral-300">
                              4.8
                            </span>
                          </div>
                          <div className="text-sm text-neutral-500">23 mentors</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-neutral-600 dark:text-neutral-300 mb-4">
                        {skill.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-neutral-500">
                          <TrendingUp className="h-4 w-4 inline mr-1" />
                          Popular this week
                        </div>
                        <Button size="sm">
                          Find Mentors
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <BookOpen className="h-12 w-12 text-neutral-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-neutral-900 dark:text-white mb-2">
                    No skills found
                  </h3>
                  <p className="text-neutral-500 mb-4">
                    Try adjusting your search or filters
                  </p>
                  <Button variant="outline">
                    Clear Filters
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <div>
            {/* Skill Exchanges */}
            {exchangesLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredExchanges.length > 0 ? (
              <div className="space-y-6">
                {filteredExchanges.map((exchange) => (
                  <SkillCard key={exchange.id} exchange={exchange} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Users className="h-12 w-12 text-neutral-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-neutral-900 dark:text-white mb-2">
                    No active exchanges found
                  </h3>
                  <p className="text-neutral-500 mb-4">
                    Be the first to create a skill exchange in this area
                  </p>
                  <Button>
                    Create Exchange
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
