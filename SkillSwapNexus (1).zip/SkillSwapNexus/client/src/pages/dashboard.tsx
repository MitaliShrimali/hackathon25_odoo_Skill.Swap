import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import StatsCard from "@/components/dashboard/stats-card";
import SkillCard from "@/components/skill-exchange/skill-card";
import ActivityFeed from "@/components/dashboard/activity-feed";
import ProfileCard from "@/components/profile/profile-card";
import NFTBadge from "@/components/profile/nft-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Handshake, 
  Coins, 
  Star, 
  Plus, 
  Search,
  TrendingUp,
  Award,
  Calendar,
  Clock
} from "lucide-react";
import type { SkillExchange, NFTBadge as NFTBadgeType, Notification } from "@/types";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: recommendedExchanges, isLoading: exchangesLoading } = useQuery<SkillExchange[]>({
    queryKey: ["/api/skill-exchanges/recommended"],
    enabled: !!user,
    retry: false,
  });

  const { data: userBadges } = useQuery<NFTBadgeType[]>({
    queryKey: ["/api/users", user?.id, "badges"],
    enabled: !!user,
    retry: false,
  });

  const { data: notifications } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    enabled: !!user,
    retry: false,
  });

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-neutral-50 dark:bg-neutral-900">
        <Navbar />
        <div className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  const unreadNotifications = notifications?.filter(n => !n.isRead).length || 0;

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-900">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Left Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <ProfileCard user={user} />
            
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full" size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Offer a Skill
                </Button>
                <Button variant="outline" className="w-full" size="sm">
                  <Search className="h-4 w-4 mr-2" />
                  Find Mentor
                </Button>
              </CardContent>
            </Card>

            {/* Recent NFT Badges */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Latest Achievements</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {userBadges?.slice(0, 2).map((badge) => (
                  <NFTBadge key={badge.id} badge={badge} />
                ))}
                {(!userBadges || userBadges.length === 0) && (
                  <p className="text-sm text-neutral-500">No badges earned yet</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* Welcome Banner */}
            <Card className="bg-gradient-to-r from-primary to-secondary text-white border-0">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold mb-2">
                      Welcome back, {user.firstName || user.email}! 👋
                    </h2>
                    <p className="text-white/90">
                      Your AI SmartMatch found {recommendedExchanges?.length || 0} perfect skill exchange opportunities today.
                    </p>
                  </div>
                  <Button variant="secondary" className="bg-white/20 hover:bg-white/30 text-white border-white/20">
                    View Matches
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Dashboard Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <StatsCard
                title="Active Swaps"
                value="7"
                change="+12%"
                changeLabel="vs last month"
                icon={Handshake}
                iconColor="text-primary"
                iconBg="bg-primary/10"
              />
              <StatsCard
                title="SkillCoins Earned"
                value={user.skillCoinBalance?.toString() || "0"}
                change="+8%"
                changeLabel="this week"
                icon={Coins}
                iconColor="text-secondary"
                iconBg="bg-secondary/10"
              />
              <StatsCard
                title="Satisfaction Rate"
                value={`${Math.round(parseFloat(user.rating || "5.0") * 20)}%`}
                change="+2%"
                changeLabel="all time high"
                icon={Star}
                iconColor="text-accent"
                iconBg="bg-accent/10"
              />
            </div>

            {/* Featured Skills & Opportunities */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Recommended Skill Exchanges</CardTitle>
                  <Tabs defaultValue="recommended" className="w-auto">
                    <TabsList>
                      <TabsTrigger value="recommended">For You</TabsTrigger>
                      <TabsTrigger value="trending">Trending</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {exchangesLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                  </div>
                ) : recommendedExchanges && recommendedExchanges.length > 0 ? (
                  recommendedExchanges.map((exchange) => (
                    <SkillCard key={exchange.id} exchange={exchange} />
                  ))
                ) : (
                  <div className="text-center py-8">
                    <p className="text-neutral-500">No recommendations available</p>
                    <Button variant="outline" className="mt-4">
                      <Search className="h-4 w-4 mr-2" />
                      Browse All Skills
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Activity & Upcoming Sessions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <ActivityFeed />
              
              {/* Upcoming Sessions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Upcoming Sessions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border border-neutral-200 dark:border-neutral-700 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Python Data Analysis</h4>
                      <Badge variant="outline" className="text-primary border-primary">Teaching</Badge>
                    </div>
                    <p className="text-sm text-neutral-600 dark:text-neutral-300 mb-2">with Lisa Chen</p>
                    <div className="flex items-center text-xs text-neutral-500 space-x-4">
                      <span className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        Tomorrow, 3:00 PM EST
                      </span>
                      <span className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        2 hours
                      </span>
                    </div>
                  </div>
                  
                  <div className="border border-neutral-200 dark:border-neutral-700 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">UI/UX Design Fundamentals</h4>
                      <Badge variant="outline" className="text-secondary border-secondary">Learning</Badge>
                    </div>
                    <p className="text-sm text-neutral-600 dark:text-neutral-300 mb-2">with Mike Taylor</p>
                    <div className="flex items-center text-xs text-neutral-500 space-x-4">
                      <span className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        Friday, 7:00 PM EST
                      </span>
                      <span className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        1.5 hours
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
