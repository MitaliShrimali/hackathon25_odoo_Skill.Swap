import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle, 
  Plus, 
  Users, 
  Award,
  TrendingUp,
  MessageSquare
} from "lucide-react";

export default function ActivityFeed() {
  // Mock activity data - in a real app this would come from an API
  const activities = [
    {
      id: 1,
      type: "completed",
      title: "Completed skill swap with Emma Wilson",
      description: "React.js mentoring session • 2 hours ago",
      icon: CheckCircle,
      iconColor: "text-accent",
      iconBg: "bg-accent/10",
    },
    {
      id: 2,
      type: "badge",
      title: "Earned new NFT badge: JavaScript Expert",
      description: "Blockchain verified • 1 day ago",
      icon: Award,
      iconColor: "text-secondary",
      iconBg: "bg-secondary/10",
    },
    {
      id: 3,
      type: "match",
      title: "New match found with David Kim",
      description: "95% compatibility • 2 days ago",
      icon: Users,
      iconColor: "text-primary",
      iconBg: "bg-primary/10",
    },
    {
      id: 4,
      type: "review",
      title: "Received 5-star review from Sarah Chen",
      description: "Python Data Science session • 3 days ago",
      icon: MessageSquare,
      iconColor: "text-yellow-500",
      iconBg: "bg-yellow-500/10",
    },
    {
      id: 5,
      type: "milestone",
      title: "Reached 50 SkillCoins earned milestone",
      description: "Keep up the great work! • 1 week ago",
      icon: TrendingUp,
      iconColor: "text-primary",
      iconBg: "bg-primary/10",
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity) => {
          const Icon = activity.icon;
          return (
            <div key={activity.id} className="flex items-start space-x-3">
              <div className={`w-8 h-8 ${activity.iconBg} rounded-full flex items-center justify-center`}>
                <Icon className={`h-4 w-4 ${activity.iconColor}`} />
              </div>
              <div className="flex-1">
                <p className="text-sm text-neutral-900 dark:text-white font-medium">
                  {activity.title}
                </p>
                <p className="text-xs text-neutral-500 mt-1">
                  {activity.description}
                </p>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
