import { Badge } from "@/components/ui/badge";
import { Award, Code, PaintbrushVertical, Database, Smartphone, Brain, Users } from "lucide-react";
import type { NFTBadge } from "@/types";

interface NFTBadgeProps {
  badge: NFTBadge;
  size?: "sm" | "md" | "lg";
}

const badgeIcons: Record<string, any> = {
  "React Expert": Code,
  "Design Mentor": PaintbrushVertical,
  "Python Expert": Code,
  "JavaScript Expert": Code,
  "Data Science": Database,
  "Mobile Development": Smartphone,
  "AI/ML Expert": Brain,
  "Community Leader": Users,
  // Fallback icon
  default: Award,
};

const badgeGradients = [
  "from-primary to-secondary",
  "from-secondary to-accent",
  "from-accent to-primary",
  "from-purple-500 to-pink-500",
  "from-blue-500 to-cyan-500",
  "from-green-500 to-blue-500",
];

export default function NFTBadge({ badge, size = "md" }: NFTBadgeProps) {
  const IconComponent = badgeIcons[badge.name] || badgeIcons.default;
  const gradientClass = badgeGradients[badge.id % badgeGradients.length];
  
  const sizeClasses = {
    sm: {
      container: "p-3",
      icon: "w-8 h-8",
      iconSize: "h-4 w-4",
      title: "text-sm font-medium",
      date: "text-xs",
    },
    md: {
      container: "p-4",
      icon: "w-10 h-10", 
      iconSize: "h-5 w-5",
      title: "text-sm font-medium",
      date: "text-xs",
    },
    lg: {
      container: "p-6",
      icon: "w-12 h-12",
      iconSize: "h-6 w-6", 
      title: "text-base font-medium",
      date: "text-sm",
    },
  };

  const classes = sizeClasses[size];

  return (
    <div className={`flex items-center space-x-3 ${classes.container} bg-gradient-to-r ${gradientClass}/10 rounded-lg border border-neutral-200 dark:border-neutral-700 hover:shadow-md transition-all duration-200 cursor-pointer group`}>
      <div className={`${classes.icon} bg-gradient-to-br ${gradientClass} rounded-lg flex items-center justify-center group-hover:scale-105 transition-transform`}>
        <IconComponent className={`${classes.iconSize} text-white`} />
      </div>
      <div className="flex-1 min-w-0">
        <div className={`${classes.title} text-neutral-900 dark:text-white truncate`}>
          {badge.name}
        </div>
        <div className={`${classes.date} text-neutral-500`}>
          Earned {new Date(badge.mintedAt!).toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric',
            year: new Date(badge.mintedAt!).getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined
          })}
        </div>
        {badge.description && size === "lg" && (
          <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1 line-clamp-2">
            {badge.description}
          </p>
        )}
      </div>
      
      {/* Blockchain verified indicator */}
      <div className="flex flex-col items-end">
        <Badge variant="outline" className="text-xs border-accent/30 text-accent bg-accent/5">
          NFT
        </Badge>
        {size !== "sm" && (
          <div className="text-xs text-neutral-400 mt-1">
            Verified
          </div>
        )}
      </div>
    </div>
  );
}
