import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import type { User } from "@/types";

interface ProfileCardProps {
  user: User;
  compact?: boolean;
}

export default function ProfileCard({ user, compact = false }: ProfileCardProps) {
  const rating = parseFloat(user.rating || "5.0");
  const starCount = Math.floor(rating);

  return (
    <Card className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700">
      <CardContent className="p-6">
        <div className="text-center">
          <Avatar className={`${compact ? 'w-16 h-16' : 'w-20 h-20'} mx-auto mb-4`}>
            <AvatarImage 
              src={user.profileImageUrl} 
              alt={`${user.firstName} ${user.lastName}`}
              className="object-cover"
            />
            <AvatarFallback className={`${compact ? 'text-lg' : 'text-xl'} bg-gradient-to-br from-primary to-secondary text-white`}>
              {user.firstName?.[0] || user.email?.[0]?.toUpperCase()}{user.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          
          <h3 className={`${compact ? 'text-lg' : 'text-xl'} font-semibold text-neutral-900 dark:text-white mb-1`}>
            {user.firstName && user.lastName 
              ? `${user.firstName} ${user.lastName}` 
              : user.email
            }
          </h3>
          
          {user.title && (
            <p className="text-neutral-500 text-sm mb-2">{user.title}</p>
          )}
          
          <div className="flex items-center justify-center mb-4">
            <div className="flex text-yellow-400 mr-2">
              {[...Array(5)].map((_, i) => (
                <Star 
                  key={i} 
                  className={`h-4 w-4 ${i < starCount ? 'fill-current' : ''}`} 
                />
              ))}
            </div>
            <span className="text-sm text-neutral-600 dark:text-neutral-300">
              {rating.toFixed(1)} ({user.totalReviews || 0} reviews)
            </span>
          </div>

          {user.bio && !compact && (
            <p className="text-sm text-neutral-600 dark:text-neutral-300 mb-4">
              {user.bio}
            </p>
          )}
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 pt-6 border-t border-neutral-100 dark:border-neutral-800">
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">{user.skillsShared || 0}</div>
            <div className="text-sm text-neutral-500">Skills Shared</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-secondary">{user.skillsLearned || 0}</div>
            <div className="text-sm text-neutral-500">Skills Learned</div>
          </div>
        </div>

        {/* SkillCoin Balance */}
        {!compact && (
          <div className="mt-4 pt-4 border-t border-neutral-100 dark:border-neutral-800">
            <div className="flex items-center justify-center space-x-2 bg-gradient-to-r from-primary/10 to-secondary/10 px-4 py-2 rounded-lg">
              <div className="w-6 h-6 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">SC</span>
              </div>
              <span className="font-semibold text-neutral-900 dark:text-white">
                {user.skillCoinBalance || 0} SkillCoins
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
