import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, Clock, Calendar, Globe, Coins } from "lucide-react";
import SkillSwapModal from "./skill-swap-modal";
import type { SkillExchange } from "@/types";

interface SkillCardProps {
  exchange: SkillExchange;
}

export default function SkillCard({ exchange }: SkillCardProps) {
  const [showModal, setShowModal] = useState(false);

  const matchScore = exchange.matchScore || 85;
  const rating = parseFloat(exchange.mentor.rating || "5.0");
  const starCount = Math.floor(rating);

  return (
    <>
      <div className="border border-neutral-200 dark:border-neutral-700 rounded-lg p-5 hover:shadow-md transition-shadow">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-4 flex-1">
            <Avatar className="w-12 h-12">
              <AvatarImage 
                src={exchange.mentor.profileImageUrl} 
                alt={`${exchange.mentor.firstName} ${exchange.mentor.lastName}`}
                className="object-cover"
              />
              <AvatarFallback>
                {exchange.mentor.firstName?.[0]}{exchange.mentor.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-2">
                <h4 className="font-semibold text-neutral-900 dark:text-white">
                  {exchange.mentor.firstName} {exchange.mentor.lastName}
                </h4>
                <Badge 
                  variant={matchScore >= 90 ? "default" : "secondary"}
                  className={matchScore >= 90 ? "bg-accent/10 text-accent" : ""}
                >
                  {matchScore}% Match
                </Badge>
              </div>
              
              <p className="text-neutral-600 dark:text-neutral-300 mb-3">
                <span className="font-medium text-primary">Offering:</span> {exchange.skillOffered.name}
                <span className="mx-2">•</span>
                <span className="font-medium text-secondary">Seeking:</span> {exchange.skillSought.name}
              </p>
              
              <div className="flex items-center space-x-4 text-sm text-neutral-500 mb-3">
                <span className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {exchange.hoursPerWeek || 2} hrs/week
                </span>
                <span className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  {exchange.schedule || "Flexible schedule"}
                </span>
                <span className="flex items-center">
                  <Globe className="h-4 w-4 mr-1" />
                  Remote + EST
                </span>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="flex text-yellow-400 text-sm">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`h-4 w-4 ${i < starCount ? 'fill-current' : ''}`} 
                    />
                  ))}
                </div>
                <span className="text-sm text-neutral-600 dark:text-neutral-300">
                  {rating} ({exchange.mentor.totalReviews || 0} reviews)
                </span>
                <Badge variant="outline" className="text-xs">
                  <Coins className="h-3 w-3 mr-1" />
                  15 SC/hr
                </Badge>
              </div>
            </div>
          </div>
          
          <Button 
            onClick={() => setShowModal(true)}
            className="ml-4"
          >
            Connect
          </Button>
        </div>
      </div>

      <SkillSwapModal 
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        exchange={exchange}
      />
    </>
  );
}
