import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Coins } from "lucide-react";
import type { SkillExchange } from "@/types";

const swapRequestSchema = z.object({
  message: z.string().min(10, "Message must be at least 10 characters"),
  schedule: z.string().min(1, "Please select a schedule"),
});

type SwapRequestData = z.infer<typeof swapRequestSchema>;

interface SkillSwapModalProps {
  isOpen: boolean;
  onClose: () => void;
  exchange: SkillExchange;
}

export default function SkillSwapModal({ isOpen, onClose, exchange }: SkillSwapModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<SwapRequestData>({
    resolver: zodResolver(swapRequestSchema),
    defaultValues: {
      message: `Hi ${exchange.mentor.firstName}! I'd love to learn ${exchange.skillOffered.name} from you. I can teach you ${exchange.skillSought.name} in return. I have experience in this area and would be excited to share my knowledge with you.`,
      schedule: "",
    },
  });

  const createExchangeMutation = useMutation({
    mutationFn: async (data: SwapRequestData) => {
      await apiRequest("POST", "/api/skill-exchanges", {
        mentorId: exchange.mentorId,
        skillOfferedId: exchange.skillOfferedId,
        skillSoughtId: exchange.skillSoughtId,
        message: data.message,
        schedule: data.schedule,
        hoursPerWeek: 2, // Default to 2 hours per week
      });
    },
    onSuccess: () => {
      toast({
        title: "Skill swap request sent!",
        description: `${exchange.mentor.firstName} will be notified and can respond within 24 hours.`,
      });
      onClose();
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/skill-exchanges"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] }); // Refresh user balance
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send skill swap request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SwapRequestData) => {
    createExchangeMutation.mutate(data);
  };

  const handleClose = () => {
    onClose();
    form.reset();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Request Skill Swap</DialogTitle>
        </DialogHeader>

        <div className="mb-6">
          <div className="flex items-center space-x-3 mb-4">
            <Avatar>
              <AvatarImage 
                src={exchange.mentor.profileImageUrl} 
                alt={`${exchange.mentor.firstName} ${exchange.mentor.lastName}`}
                className="object-cover"
              />
              <AvatarFallback>
                {exchange.mentor.firstName?.[0]}{exchange.mentor.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-medium">
                {exchange.mentor.firstName} {exchange.mentor.lastName}
              </h3>
              <p className="text-sm text-neutral-500">{exchange.mentor.title}</p>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Badge className="bg-primary/10 text-primary">You'll Learn</Badge>
              <span className="text-sm">{exchange.skillOffered.name}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className="bg-secondary/10 text-secondary">You'll Teach</Badge>
              <span className="text-sm">{exchange.skillSought.name}</span>
            </div>
          </div>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field}
                      rows={4}
                      placeholder="Introduce yourself and explain why you'd like to connect..."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="schedule"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Proposed Schedule</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your preferred schedule" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="2 hours/week - Flexible timing">
                        2 hours/week - Flexible timing
                      </SelectItem>
                      <SelectItem value="1 hour/week - Weekends only">
                        1 hour/week - Weekends only
                      </SelectItem>
                      <SelectItem value="3 hours/week - Evenings preferred">
                        3 hours/week - Evenings preferred
                      </SelectItem>
                      <SelectItem value="4 hours/week - Mornings preferred">
                        4 hours/week - Mornings preferred
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex items-center space-x-3 pt-4">
              <Button 
                type="submit" 
                className="flex-1"
                disabled={createExchangeMutation.isPending}
              >
                {createExchangeMutation.isPending ? (
                  "Sending..."
                ) : (
                  <>
                    <Coins className="h-4 w-4 mr-2" />
                    Send Request (5 SC)
                  </>
                )}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                className="flex-1"
                onClick={handleClose}
                disabled={createExchangeMutation.isPending}
              >
                Cancel
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
