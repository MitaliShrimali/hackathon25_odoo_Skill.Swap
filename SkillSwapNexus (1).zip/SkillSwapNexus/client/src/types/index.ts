export interface User {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  title?: string;
  bio?: string;
  skillCoinBalance?: number;
  rating?: string;
  totalReviews?: number;
  skillsShared?: number;
  skillsLearned?: number;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Skill {
  id: number;
  name: string;
  category: string;
  description?: string;
  createdAt?: Date;
}

export interface UserSkill {
  id: number;
  userId: string;
  skillId: number;
  proficiencyLevel: string;
  isOffering: boolean;
  isSeeking: boolean;
  hourlyRate?: number;
  createdAt?: Date;
  skill: Skill;
}

export interface SkillExchange {
  id: number;
  mentorId: string;
  menteeId: string;
  skillOfferedId: number;
  skillSoughtId: number;
  status: string;
  hoursPerWeek?: number;
  schedule?: string;
  message?: string;
  matchScore?: number;
  createdAt?: Date;
  updatedAt?: Date;
  mentor: User;
  mentee: User;
  skillOffered: Skill;
  skillSought: Skill;
}

export interface NFTBadge {
  id: number;
  userId: string;
  name: string;
  description?: string;
  imageUrl?: string;
  skillId?: number;
  metadata?: any;
  mintedAt?: Date;
}

export interface Review {
  id: number;
  reviewerId: string;
  revieweeId: string;
  exchangeId: number;
  rating: number;
  comment?: string;
  createdAt?: Date;
  reviewer: User;
}

export interface Notification {
  id: number;
  userId: string;
  type: string;
  title: string;
  message?: string;
  isRead: boolean;
  relatedId?: number;
  createdAt?: Date;
}

export interface SkillCoinTransaction {
  id: number;
  fromUserId?: string;
  toUserId: string;
  amount: number;
  type: string;
  description?: string;
  exchangeId?: number;
  createdAt?: Date;
}
