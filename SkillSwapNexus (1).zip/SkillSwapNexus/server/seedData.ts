import { db } from "./db";
import { skills } from "@shared/schema";

const INITIAL_SKILLS = [
  // Programming
  { name: "JavaScript", category: "Programming", description: "Modern web development with ES6+ features" },
  { name: "Python", category: "Programming", description: "Data science and web development" },
  { name: "React", category: "Programming", description: "Frontend web framework" },
  { name: "Node.js", category: "Programming", description: "Backend JavaScript development" },
  { name: "TypeScript", category: "Programming", description: "Type-safe JavaScript development" },
  
  // Design
  { name: "UI/UX Design", category: "Design", description: "User interface and experience design" },
  { name: "Graphic Design", category: "Design", description: "Visual communication and branding" },
  { name: "Figma", category: "Design", description: "Collaborative interface design tool" },
  { name: "Adobe Photoshop", category: "Design", description: "Digital image editing and manipulation" },
  
  // Marketing
  { name: "Digital Marketing", category: "Marketing", description: "Online marketing strategies and campaigns" },
  { name: "SEO", category: "Marketing", description: "Search engine optimization" },
  { name: "Content Writing", category: "Marketing", description: "Creating engaging written content" },
  { name: "Social Media Marketing", category: "Marketing", description: "Building brand presence on social platforms" },
  
  // Business
  { name: "Project Management", category: "Business", description: "Planning and executing projects effectively" },
  { name: "Data Analysis", category: "Business", description: "Interpreting data to drive business decisions" },
  { name: "Financial Planning", category: "Business", description: "Personal and business financial strategies" },
  
  // Languages
  { name: "Spanish", category: "Languages", description: "Conversational and business Spanish" },
  { name: "French", category: "Languages", description: "French language for travel and business" },
  { name: "Mandarin Chinese", category: "Languages", description: "Mandarin Chinese conversation" },
  
  // Creative
  { name: "Photography", category: "Creative", description: "Digital photography and photo editing" },
  { name: "Video Editing", category: "Creative", description: "Creating and editing video content" },
  { name: "Music Production", category: "Creative", description: "Creating and mixing music" },
  { name: "Writing", category: "Creative", description: "Creative and technical writing" },
  
  // Technology
  { name: "Blockchain", category: "Technology", description: "Cryptocurrency and blockchain development" },
  { name: "Machine Learning", category: "Technology", description: "AI and ML model development" },
  { name: "Cybersecurity", category: "Technology", description: "Information security and protection" },
  { name: "Cloud Computing", category: "Technology", description: "AWS, Azure, and Google Cloud platforms" },
];

export async function seedInitialData() {
  try {
    console.log("🌱 Seeding initial skills data...");
    
    // Check if skills already exist
    const existingSkills = await db.select().from(skills);
    if (existingSkills.length > 0) {
      console.log("✅ Skills already seeded, skipping...");
      return;
    }
    
    // Insert initial skills
    await db.insert(skills).values(INITIAL_SKILLS);
    
    console.log(`✅ Successfully seeded ${INITIAL_SKILLS.length} skills!`);
  } catch (error) {
    console.error("❌ Error seeding data:", error);
  }
}