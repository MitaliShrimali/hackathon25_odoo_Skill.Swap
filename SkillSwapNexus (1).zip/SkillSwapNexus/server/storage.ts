import {
  users,
  skills,
  userSkills,
  skillExchanges,
  skillCoinTransactions,
  nftBadges,
  reviews,
  notifications,
  type User,
  type UpsertUser,
  type Skill,
  type InsertSkill,
  type UserSkill,
  type InsertUserSkill,
  type SkillExchange,
  type InsertSkillExchange,
  type SkillCoinTransaction,
  type InsertSkillCoinTransaction,
  type NFTBadge,
  type InsertNFTBadge,
  type Review,
  type InsertReview,
  type Notification,
  type InsertNotification,
} from "@shared/schema";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Skill operations
  getAllSkills(): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  getUserSkills(userId: string): Promise<(UserSkill & { skill: Skill })[]>;
  addUserSkill(userSkill: InsertUserSkill): Promise<UserSkill>;
  
  // Skill exchange operations
  getSkillExchanges(filters?: { mentorId?: string; menteeId?: string; status?: string }): Promise<(SkillExchange & { mentor: User; mentee: User; skillOffered: Skill; skillSought: Skill })[]>;
  createSkillExchange(exchange: InsertSkillExchange): Promise<SkillExchange>;
  updateSkillExchange(id: number, updates: Partial<SkillExchange>): Promise<SkillExchange>;
  getRecommendedExchanges(userId: string): Promise<(SkillExchange & { mentor: User; mentee: User; skillOffered: Skill; skillSought: Skill })[]>;
  
  // Transaction operations
  createTransaction(transaction: InsertSkillCoinTransaction): Promise<SkillCoinTransaction>;
  getUserTransactions(userId: string): Promise<SkillCoinTransaction[]>;
  updateUserBalance(userId: string, amount: number): Promise<void>;
  
  // NFT Badge operations
  getUserBadges(userId: string): Promise<NFTBadge[]>;
  createBadge(badge: InsertNFTBadge): Promise<NFTBadge>;
  
  // Review operations
  createReview(review: InsertReview): Promise<Review>;
  getUserReviews(userId: string): Promise<(Review & { reviewer: User })[]>;
  
  // Notification operations
  getUserNotifications(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private skills: Map<number, Skill> = new Map();
  private userSkills: Map<number, UserSkill> = new Map();
  private skillExchanges: Map<number, SkillExchange> = new Map();
  private transactions: Map<number, SkillCoinTransaction> = new Map();
  private badges: Map<number, NFTBadge> = new Map();
  private reviews: Map<number, Review> = new Map();
  private notifications: Map<number, Notification> = new Map();
  
  private currentSkillId = 1;
  private currentUserSkillId = 1;
  private currentExchangeId = 1;
  private currentTransactionId = 1;
  private currentBadgeId = 1;
  private currentReviewId = 1;
  private currentNotificationId = 1;

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Seed skills
    const skillsData = [
      { name: "React.js", category: "Frontend Development", description: "Modern React development with hooks and context" },
      { name: "Python", category: "Programming", description: "Python programming for web development and data science" },
      { name: "UI/UX Design", category: "Design", description: "User interface and experience design principles" },
      { name: "Node.js", category: "Backend Development", description: "Server-side JavaScript development" },
      { name: "Data Science", category: "Analytics", description: "Data analysis and machine learning" },
      { name: "Mobile Development", category: "Mobile", description: "iOS and Android app development" },
    ];

    skillsData.forEach(skill => {
      const newSkill: Skill = {
        id: this.currentSkillId++,
        ...skill,
        createdAt: new Date(),
      };
      this.skills.set(newSkill.id, newSkill);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = this.users.get(userData.id);
    const user: User = {
      ...existingUser,
      ...userData,
      title: userData.title || existingUser?.title || null,
      bio: userData.bio || existingUser?.bio || null,
      skillCoinBalance: userData.skillCoinBalance ?? existingUser?.skillCoinBalance ?? 100,
      rating: userData.rating || existingUser?.rating || "5.0",
      totalReviews: userData.totalReviews ?? existingUser?.totalReviews ?? 0,
      skillsShared: userData.skillsShared ?? existingUser?.skillsShared ?? 0,
      skillsLearned: userData.skillsLearned ?? existingUser?.skillsLearned ?? 0,
      updatedAt: new Date(),
      createdAt: existingUser?.createdAt || new Date(),
    };
    this.users.set(userData.id, user);
    return user;
  }

  async getAllSkills(): Promise<Skill[]> {
    return Array.from(this.skills.values());
  }

  async createSkill(skillData: InsertSkill): Promise<Skill> {
    const skill: Skill = {
      id: this.currentSkillId++,
      name: skillData.name,
      category: skillData.category,
      description: skillData.description || null,
      createdAt: new Date(),
    };
    this.skills.set(skill.id, skill);
    return skill;
  }

  async getUserSkills(userId: string): Promise<(UserSkill & { skill: Skill })[]> {
    const userSkills = Array.from(this.userSkills.values()).filter(us => us.userId === userId);
    return userSkills.map(us => ({
      ...us,
      skill: this.skills.get(us.skillId)!,
    }));
  }

  async addUserSkill(userSkillData: InsertUserSkill): Promise<UserSkill> {
    const userSkill: UserSkill = {
      id: this.currentUserSkillId++,
      userId: userSkillData.userId,
      skillId: userSkillData.skillId,
      proficiencyLevel: userSkillData.proficiencyLevel,
      isOffering: userSkillData.isOffering ?? true,
      isSeeking: userSkillData.isSeeking ?? false,
      hourlyRate: userSkillData.hourlyRate || null,
      createdAt: new Date(),
    };
    this.userSkills.set(userSkill.id, userSkill);
    return userSkill;
  }

  async getSkillExchanges(filters?: { mentorId?: string; menteeId?: string; status?: string }): Promise<(SkillExchange & { mentor: User; mentee: User; skillOffered: Skill; skillSought: Skill })[]> {
    let exchanges = Array.from(this.skillExchanges.values());
    
    if (filters) {
      if (filters.mentorId) exchanges = exchanges.filter(e => e.mentorId === filters.mentorId);
      if (filters.menteeId) exchanges = exchanges.filter(e => e.menteeId === filters.menteeId);
      if (filters.status) exchanges = exchanges.filter(e => e.status === filters.status);
    }

    return exchanges.map(exchange => ({
      ...exchange,
      mentor: this.users.get(exchange.mentorId)!,
      mentee: this.users.get(exchange.menteeId)!,
      skillOffered: this.skills.get(exchange.skillOfferedId)!,
      skillSought: this.skills.get(exchange.skillSoughtId)!,
    }));
  }

  async createSkillExchange(exchangeData: InsertSkillExchange): Promise<SkillExchange> {
    const exchange: SkillExchange = {
      id: this.currentExchangeId++,
      mentorId: exchangeData.mentorId,
      menteeId: exchangeData.menteeId,
      skillOfferedId: exchangeData.skillOfferedId,
      skillSoughtId: exchangeData.skillSoughtId,
      status: exchangeData.status || "pending",
      hoursPerWeek: exchangeData.hoursPerWeek || null,
      schedule: exchangeData.schedule || null,
      message: exchangeData.message || null,
      matchScore: exchangeData.matchScore || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.skillExchanges.set(exchange.id, exchange);
    return exchange;
  }

  async updateSkillExchange(id: number, updates: Partial<SkillExchange>): Promise<SkillExchange> {
    const exchange = this.skillExchanges.get(id);
    if (!exchange) throw new Error("Exchange not found");
    
    const updatedExchange = { ...exchange, ...updates, updatedAt: new Date() };
    this.skillExchanges.set(id, updatedExchange);
    return updatedExchange;
  }

  async getRecommendedExchanges(userId: string): Promise<(SkillExchange & { mentor: User; mentee: User; skillOffered: Skill; skillSought: Skill })[]> {
    // Simple recommendation: get exchanges from other users that are pending
    const exchanges = Array.from(this.skillExchanges.values())
      .filter(e => e.mentorId !== userId && e.status === "pending")
      .slice(0, 5); // Limit to 5 recommendations

    return exchanges.map(exchange => ({
      ...exchange,
      mentor: this.users.get(exchange.mentorId)!,
      mentee: this.users.get(exchange.menteeId)!,
      skillOffered: this.skills.get(exchange.skillOfferedId)!,
      skillSought: this.skills.get(exchange.skillSoughtId)!,
    }));
  }

  async createTransaction(transactionData: InsertSkillCoinTransaction): Promise<SkillCoinTransaction> {
    const transaction: SkillCoinTransaction = {
      id: this.currentTransactionId++,
      fromUserId: transactionData.fromUserId || null,
      toUserId: transactionData.toUserId,
      amount: transactionData.amount,
      type: transactionData.type,
      description: transactionData.description || null,
      exchangeId: transactionData.exchangeId || null,
      createdAt: new Date(),
    };
    this.transactions.set(transaction.id, transaction);
    return transaction;
  }

  async getUserTransactions(userId: string): Promise<SkillCoinTransaction[]> {
    return Array.from(this.transactions.values())
      .filter(t => t.fromUserId === userId || t.toUserId === userId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async updateUserBalance(userId: string, amount: number): Promise<void> {
    const user = this.users.get(userId);
    if (user) {
      user.skillCoinBalance = (user.skillCoinBalance || 0) + amount;
      this.users.set(userId, user);
    }
  }

  async getUserBadges(userId: string): Promise<NFTBadge[]> {
    return Array.from(this.badges.values())
      .filter(b => b.userId === userId)
      .sort((a, b) => b.mintedAt!.getTime() - a.mintedAt!.getTime());
  }

  async createBadge(badgeData: InsertNFTBadge): Promise<NFTBadge> {
    const badge: NFTBadge = {
      id: this.currentBadgeId++,
      userId: badgeData.userId,
      name: badgeData.name,
      description: badgeData.description || null,
      imageUrl: badgeData.imageUrl || null,
      skillId: badgeData.skillId || null,
      metadata: badgeData.metadata || {},
      mintedAt: new Date(),
    };
    this.badges.set(badge.id, badge);
    return badge;
  }

  async createReview(reviewData: InsertReview): Promise<Review> {
    const review: Review = {
      id: this.currentReviewId++,
      reviewerId: reviewData.reviewerId,
      revieweeId: reviewData.revieweeId,
      exchangeId: reviewData.exchangeId,
      rating: reviewData.rating,
      comment: reviewData.comment || null,
      createdAt: new Date(),
    };
    this.reviews.set(review.id, review);
    
    // Update reviewee's rating
    await this.updateUserRating(reviewData.revieweeId);
    
    return review;
  }

  private async updateUserRating(userId: string): Promise<void> {
    const userReviews = Array.from(this.reviews.values()).filter(r => r.revieweeId === userId);
    if (userReviews.length > 0) {
      const avgRating = userReviews.reduce((sum, r) => sum + r.rating, 0) / userReviews.length;
      const user = this.users.get(userId);
      if (user) {
        user.rating = avgRating.toFixed(2);
        user.totalReviews = userReviews.length;
        this.users.set(userId, user);
      }
    }
  }

  async getUserReviews(userId: string): Promise<(Review & { reviewer: User })[]> {
    const userReviews = Array.from(this.reviews.values()).filter(r => r.revieweeId === userId);
    return userReviews.map(review => ({
      ...review,
      reviewer: this.users.get(review.reviewerId)!,
    }));
  }

  async getUserNotifications(userId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(n => n.userId === userId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const notification: Notification = {
      id: this.currentNotificationId++,
      userId: notificationData.userId,
      type: notificationData.type,
      title: notificationData.title,
      message: notificationData.message || null,
      isRead: notificationData.isRead ?? false,
      relatedId: notificationData.relatedId || null,
      createdAt: new Date(),
    };
    this.notifications.set(notification.id, notification);
    return notification;
  }

  async markNotificationRead(id: number): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.isRead = true;
      this.notifications.set(id, notification);
    }
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Skill operations
  async getAllSkills(): Promise<Skill[]> {
    return await db.select().from(skills);
  }

  async createSkill(skillData: InsertSkill): Promise<Skill> {
    const [skill] = await db.insert(skills).values(skillData).returning();
    return skill;
  }

  async getUserSkills(userId: string): Promise<(UserSkill & { skill: Skill })[]> {
    return await db
      .select()
      .from(userSkills)
      .leftJoin(skills, eq(userSkills.skillId, skills.id))
      .where(eq(userSkills.userId, userId))
      .then(rows => 
        rows.map(row => ({
          ...row.user_skills,
          skill: row.skills!,
        }))
      );
  }

  async addUserSkill(userSkillData: InsertUserSkill): Promise<UserSkill> {
    const [userSkill] = await db.insert(userSkills).values(userSkillData).returning();
    return userSkill;
  }

  // Skill exchange operations
  async getSkillExchanges(filters?: { mentorId?: string; menteeId?: string; status?: string }): Promise<(SkillExchange & { mentor: User; mentee: User; skillOffered: Skill; skillSought: Skill })[]> {
    const query = db
      .select()
      .from(skillExchanges)
      .leftJoin(users, eq(skillExchanges.mentorId, users.id))
      .leftJoin(skills, eq(skillExchanges.skillOfferedId, skills.id));

    // Apply filters if provided
    let whereConditions = [];
    if (filters?.mentorId) whereConditions.push(eq(skillExchanges.mentorId, filters.mentorId));
    if (filters?.menteeId) whereConditions.push(eq(skillExchanges.menteeId, filters.menteeId));
    if (filters?.status) whereConditions.push(eq(skillExchanges.status, filters.status));

    const results = await query;
    
    // Transform results to include related data
    return results.map(row => ({
      ...row.skill_exchanges,
      mentor: row.users!,
      mentee: row.users!, // This would need a separate join for mentee
      skillOffered: row.skills!,
      skillSought: row.skills!, // This would need a separate join for skillSought
    }));
  }

  async createSkillExchange(exchangeData: InsertSkillExchange): Promise<SkillExchange> {
    const [exchange] = await db.insert(skillExchanges).values(exchangeData).returning();
    return exchange;
  }

  async updateSkillExchange(id: number, updates: Partial<SkillExchange>): Promise<SkillExchange> {
    const [exchange] = await db
      .update(skillExchanges)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(skillExchanges.id, id))
      .returning();
    return exchange;
  }

  async getRecommendedExchanges(userId: string): Promise<(SkillExchange & { mentor: User; mentee: User; skillOffered: Skill; skillSought: Skill })[]> {
    // For now, return all pending exchanges
    return this.getSkillExchanges({ status: "pending" });
  }

  // Transaction operations
  async createTransaction(transactionData: InsertSkillCoinTransaction): Promise<SkillCoinTransaction> {
    const [transaction] = await db.insert(skillCoinTransactions).values(transactionData).returning();
    return transaction;
  }

  async getUserTransactions(userId: string): Promise<SkillCoinTransaction[]> {
    return await db
      .select()
      .from(skillCoinTransactions)
      .where(sql`${skillCoinTransactions.toUserId} = ${userId} OR ${skillCoinTransactions.fromUserId} = ${userId}`)
      .orderBy(sql`${skillCoinTransactions.createdAt} DESC`);
  }

  async updateUserBalance(userId: string, amount: number): Promise<void> {
    await db
      .update(users)
      .set({ 
        skillCoinBalance: sql`${users.skillCoinBalance} + ${amount}`,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId));
  }

  // NFT Badge operations
  async getUserBadges(userId: string): Promise<NFTBadge[]> {
    return await db
      .select()
      .from(nftBadges)
      .where(eq(nftBadges.userId, userId))
      .orderBy(sql`${nftBadges.mintedAt} DESC`);
  }

  async createBadge(badgeData: InsertNFTBadge): Promise<NFTBadge> {
    const [badge] = await db.insert(nftBadges).values(badgeData).returning();
    return badge;
  }

  // Review operations
  async createReview(reviewData: InsertReview): Promise<Review> {
    const [review] = await db.insert(reviews).values(reviewData).returning();
    
    // Update user rating
    await this.updateUserRating(reviewData.revieweeId);
    
    return review;
  }

  private async updateUserRating(userId: string): Promise<void> {
    const userReviews = await db
      .select()
      .from(reviews)
      .where(eq(reviews.revieweeId, userId));
      
    if (userReviews.length > 0) {
      const avgRating = userReviews.reduce((sum, r) => sum + r.rating, 0) / userReviews.length;
      await db
        .update(users)
        .set({ 
          rating: avgRating.toFixed(2),
          totalReviews: userReviews.length,
          updatedAt: new Date()
        })
        .where(eq(users.id, userId));
    }
  }

  async getUserReviews(userId: string): Promise<(Review & { reviewer: User })[]> {
    return await db
      .select()
      .from(reviews)
      .leftJoin(users, eq(reviews.reviewerId, users.id))
      .where(eq(reviews.revieweeId, userId))
      .then(rows => 
        rows.map(row => ({
          ...row.reviews,
          reviewer: row.users!,
        }))
      );
  }

  // Notification operations
  async getUserNotifications(userId: string): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(sql`${notifications.createdAt} DESC`);
  }

  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const [notification] = await db.insert(notifications).values(notificationData).returning();
    return notification;
  }

  async markNotificationRead(id: number): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
  }
}

export const storage = new DatabaseStorage();
