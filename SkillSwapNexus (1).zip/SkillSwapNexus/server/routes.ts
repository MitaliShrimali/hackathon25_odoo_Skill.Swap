import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertSkillExchangeSchema, insertReviewSchema, insertUserSkillSchema, insertNotificationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Skills routes
  app.get('/api/skills', async (req, res) => {
    try {
      const skills = await storage.getAllSkills();
      res.json(skills);
    } catch (error) {
      console.error("Error fetching skills:", error);
      res.status(500).json({ message: "Failed to fetch skills" });
    }
  });

  app.get('/api/users/:userId/skills', isAuthenticated, async (req, res) => {
    try {
      const { userId } = req.params;
      const userSkills = await storage.getUserSkills(userId);
      res.json(userSkills);
    } catch (error) {
      console.error("Error fetching user skills:", error);
      res.status(500).json({ message: "Failed to fetch user skills" });
    }
  });

  app.post('/api/users/:userId/skills', isAuthenticated, async (req: any, res) => {
    try {
      const { userId } = req.params;
      const currentUserId = req.user.claims.sub;
      
      if (userId !== currentUserId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const userSkillData = insertUserSkillSchema.parse({ ...req.body, userId });
      const userSkill = await storage.addUserSkill(userSkillData);
      res.json(userSkill);
    } catch (error) {
      console.error("Error adding user skill:", error);
      res.status(500).json({ message: "Failed to add user skill" });
    }
  });

  // Skill exchanges routes
  app.get('/api/skill-exchanges', isAuthenticated, async (req: any, res) => {
    try {
      const { status, mentorId, menteeId } = req.query;
      const filters: any = {};
      if (status) filters.status = status;
      if (mentorId) filters.mentorId = mentorId;
      if (menteeId) filters.menteeId = menteeId;

      const exchanges = await storage.getSkillExchanges(filters);
      res.json(exchanges);
    } catch (error) {
      console.error("Error fetching skill exchanges:", error);
      res.status(500).json({ message: "Failed to fetch skill exchanges" });
    }
  });

  app.get('/api/skill-exchanges/recommended', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const exchanges = await storage.getRecommendedExchanges(userId);
      res.json(exchanges);
    } catch (error) {
      console.error("Error fetching recommended exchanges:", error);
      res.status(500).json({ message: "Failed to fetch recommended exchanges" });
    }
  });

  app.post('/api/skill-exchanges', isAuthenticated, async (req: any, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const exchangeData = insertSkillExchangeSchema.parse({
        ...req.body,
        menteeId: currentUserId,
        matchScore: Math.floor(Math.random() * 20) + 80, // Mock AI matching score 80-100
      });

      const exchange = await storage.createSkillExchange(exchangeData);
      
      // Create notification for mentor
      await storage.createNotification({
        userId: exchangeData.mentorId,
        type: "exchange_request",
        title: "New Skill Exchange Request",
        message: `You have a new skill exchange request from ${req.user.claims.first_name || 'someone'}`,
        relatedId: exchange.id,
      });

      // Deduct SkillCoins for request (5 SC)
      await storage.updateUserBalance(currentUserId, -5);
      await storage.createTransaction({
        fromUserId: currentUserId,
        toUserId: currentUserId, // Self-transaction for request fee
        amount: -5,
        type: "spending",
        description: "Skill exchange request fee",
        exchangeId: exchange.id,
      });

      res.json(exchange);
    } catch (error) {
      console.error("Error creating skill exchange:", error);
      res.status(500).json({ message: "Failed to create skill exchange" });
    }
  });

  app.patch('/api/skill-exchanges/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const currentUserId = req.user.claims.sub;
      const updates = req.body;

      // Get the exchange to verify permissions
      const exchanges = await storage.getSkillExchanges();
      const exchange = exchanges.find(e => e.id === parseInt(id));
      
      if (!exchange) {
        return res.status(404).json({ message: "Exchange not found" });
      }

      if (exchange.mentorId !== currentUserId && exchange.menteeId !== currentUserId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const updatedExchange = await storage.updateSkillExchange(parseInt(id), updates);

      // Handle status changes
      if (updates.status === "accepted") {
        await storage.createNotification({
          userId: exchange.menteeId,
          type: "exchange_accepted",
          title: "Skill Exchange Accepted",
          message: `${exchange.mentor.firstName || 'Someone'} accepted your skill exchange request`,
          relatedId: exchange.id,
        });
      }

      res.json(updatedExchange);
    } catch (error) {
      console.error("Error updating skill exchange:", error);
      res.status(500).json({ message: "Failed to update skill exchange" });
    }
  });

  // Reviews routes
  app.post('/api/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        reviewerId: currentUserId,
      });

      const review = await storage.createReview(reviewData);
      
      // Award SkillCoins for leaving a review
      await storage.updateUserBalance(currentUserId, 5);
      await storage.createTransaction({
        fromUserId: null,
        toUserId: currentUserId,
        amount: 5,
        type: "earning",
        description: "Review completion bonus",
        exchangeId: reviewData.exchangeId,
      });

      res.json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.get('/api/users/:userId/reviews', async (req, res) => {
    try {
      const { userId } = req.params;
      const reviews = await storage.getUserReviews(userId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching user reviews:", error);
      res.status(500).json({ message: "Failed to fetch user reviews" });
    }
  });

  // Transactions routes
  app.get('/api/users/:userId/transactions', isAuthenticated, async (req: any, res) => {
    try {
      const { userId } = req.params;
      const currentUserId = req.user.claims.sub;

      if (userId !== currentUserId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const transactions = await storage.getUserTransactions(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // NFT Badges routes
  app.get('/api/users/:userId/badges', async (req, res) => {
    try {
      const { userId } = req.params;
      const badges = await storage.getUserBadges(userId);
      res.json(badges);
    } catch (error) {
      console.error("Error fetching user badges:", error);
      res.status(500).json({ message: "Failed to fetch user badges" });
    }
  });

  // Notifications routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch('/api/notifications/:id/read', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.markNotificationRead(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Profile update route
  app.patch('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updates = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const updatedUser = await storage.upsertUser({
        ...user,
        ...updates,
      });

      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
